window.onload = function () {
    var start = document.getElementById("start"), // Menu
        setgs = document.getElementById("setgs"),
        back = document.getElementById("back"),
        exit = document.getElementById("exit");
    var divSizePlus = document.getElementById("divSizePlus"), // Blocks in settings
        divSizeMinus = document.getElementById("divSizeMinus"),
        divSpeedPlus = document.getElementById("divSpeedPlus"),
        divSpeedMinus = document.getElementById("divSpeedMinus");
    var sizePlus = document.getElementById("sizePlus"), // Buttons in settings
        sizeMinus = document.getElementById("sizeMinus"),
        speedPlus = document.getElementById("speedPlus"),
        speedMinus = document.getElementById("speedMinus");
    var timer; // Timer for settings
    var timer1; // Timer for game
    var circle = document.getElementById("circle");
    var circle1 = document.getElementById("circle1");// Circle
    var score = document.getElementById("score"), // Points
        points = document.getElementById("points"); 
    var size = document.getElementById("size"); // Current size
    var speed = document.getElementById("speed"); // Current speed
    var con = 0; // Variable for changing the location of the ball in the settings
    var changeSpeed = 800; // Variable for timer's
    var defSize = 80; // Default size 
    var radius = 50; // Default radius
    
    setgs.onclick = function () { // Settings
        back.style.margin = "90px 0 0 500px";
        divSizePlus.style.display = "block";
        divSizeMinus.style.display = "block";
        divSpeedPlus.style.display = "block";
        divSpeedMinus.style.display = "block";
        back.style.display = "block";
        circle1.style.display = "block";
        size.style.display = "block";
        speed.style.display = "block";
        start.style.display = "none";
        setgs.style.display = "none";
        
        var plusSize = 80,
            minusSize = 80,
            sumPlus = 0,
            sumMinus = 0,
            counter = 5;
        
        sizePlus.onclick = function () { // + Size
            if (defSize === 110) {
                plusSize.style.cursor = "none";   
            }
            plusSize = defSize;
            sumPlus = plusSize + counter;
            circle1.style.borderRadius = radius + "px";
            circle1.style.width = sumPlus + "px";
            circle1.style.height = sumPlus + "px";
            plusSize = sumPlus;
            defSize = plusSize; 
            radius = radius + counter;
            size.innerHTML = "(" + defSize + ")";
        };
        
        sizeMinus.onclick = function () { // - Size
            if (defSize === 15) {
                minusSize.style.cursor = "none";
            }
            minusSize = defSize;
            sumMinus = minusSize - counter;
            circle1.style.width = sumMinus + "px";
            circle1.style.height = sumMinus + "px";
            minusSize = sumMinus;
            defSize = minusSize;
            size.innerHTML = "(" + defSize + ")";
        };
        
        speedPlus.onclick = function () { // + speed
            if (changeSpeed === 350) {
                changeSpeed.style.cursor = "none";   
            }
            changeSpeed = changeSpeed - 50;
            clearInterval(timer1);
            speed.innerHTML = "(" + changeSpeed + ")";
            timer1 = setInterval(setgsOfSpeed, changeSpeed);
        }; 
        
        speedMinus.onclick = function () { // - speed
            if (changeSpeed === 3000) {
                changeSpeed.style.cursor = "none";   
            }
            changeSpeed = changeSpeed + 50;
            clearInterval(timer1);
            speed.innerHTML = "(" + changeSpeed + ")";
            timer1 = setInterval(setgsOfSpeed, changeSpeed);
        };
        
        function setgsOfSpeed () { // Changing the location of the circle (settings)
            con++;
            if ( (con%2) === 1 ) {
                circle1.style.left = -350 + "px";
            }
            else if ( (con%2) === 0 ) {
                circle1.style.left = -160 + "px";    
            }
        }
        timer1 = setInterval(setgsOfSpeed, changeSpeed); // timer for settings
    }
    
    back.onclick = function () { // Exit the settings
        clearInterval(timer1);
        divSizePlus.style.display = "none";
        divSizeMinus.style.display = "none";
        divSpeedPlus.style.display = "none";
        divSpeedMinus.style.display = "none";
        circle1.style.display = "none";
        back.style.display = "none";
        size.style.display = "none";
        speed.style.display = "none";
        start.style.display = "block";
        setgs.style.display = "block";
        circle.style.height = defSize + "px";
        circle.style.width = defSize + "px";
        circle.style.borderRadius = radius + "px";
    }
    
    start.onclick = function () { // Start the game
        circle.style.margin = "-5px 0 0";
        start.style.display = "none";
        setgs.style.display = "none";
        circle.style.display = "block";
        exit.style.display = "block";
        score.style.display = "block";
        points.style.display = "block";
        var count = 0; // Очки
        
        function position () { // Changing the location of the circle (game)
            var x = window.innerWidth, 
                y = window.innerHeight;
                circle.style.left = getRandom(1, x - 110) + "px";
                circle.style.top = getRandom(1, y - 110) + "px";
        };
        timer = setInterval(position, changeSpeed); // Timer for game
        
        circle.onclick = function () { // Scoring
            circle.style.backgroundColor = "hsl(" + getRandom(0, 360) + ", 60%, 50%)"; 
            count++;
            score.innerHTML = count; 
        };
        
        function getRandom(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }; 
    }
    
    exit.onclick = function () { // End of the game
        clearInterval(timer);
        score.innerHTML = ""; // Reset the score
        circle.style.backgroundColor = "aqua";
        circle.style.display = "none";
        exit.style.display = "none";
        points.style.display = "none";
        score.style.display = "none";
        start.style.display = "block";
        setgs.style.display = "block";
    }  
}